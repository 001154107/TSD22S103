﻿$AppToRemove = Get-AppxPackage -Name *StartFinance*
Remove-AppxPackage $AppToRemove
